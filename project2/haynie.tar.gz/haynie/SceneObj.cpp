// SceneObj.cpp

#include "SceneObj.h"

SceneObj::SceneObj(int type) {
  this->type = type;
};

SceneObj::~SceneObj() {};
