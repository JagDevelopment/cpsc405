// Light.cpp

/*
Name: Kevin Haynie
Date: 2/20/2014
Project: 3 - Looking a Bit Shady!
Filename: Light.cpp
*/

#include "PointLight.h"

Light::Light() {
  next = NULL;
  prev=  NULL;
}

Light::~Light() {}
