// SceneObj.cpp

/*
Name: Kevin Haynie
Date: 2/20/2014
Project: 3 - Looking a Bit Shady!
Filename: SceneObj.cpp
*/

#include "SceneObj.h"

SceneObj::SceneObj(int type) {
  this->type = type;
};

SceneObj::~SceneObj() {};
