// SceneObj.cpp

/*
Name: Kevin Haynie
Date: 3/3/2014
Project: 4 - Ooh, shiny!
Filename: SceneObj.cpp
*/

#include "SceneObj.h"

SceneObj::SceneObj(int type) {
  this->type = type;
};

SceneObj::~SceneObj() {};
