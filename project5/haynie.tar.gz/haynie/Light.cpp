// Light.cpp

/*
Name: Kevin Haynie
Date: 3/3/2014
Project: 4 - Ooh, shiny!
Filename: Light.cpp
*/

#include "PointLight.h"

Light::Light() {
  next = NULL;
  prev=  NULL;
}

Light::~Light() {}
